# My Package

This is a simple Python package that demonstrates how to create a Python package.

## Installation

You can install this package using pip:
